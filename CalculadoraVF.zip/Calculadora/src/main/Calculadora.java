package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Calculadora {
    @SuppressWarnings("CallToPrintStackTrace")
    public static void main(String[] args) {
        String acc="";
        int tipo;
        float num1, num2, res;
        double ang, rad, tot, pot, base;
        Scanner in= new Scanner(System.in);
        do{
            System.out.println("->Calculadora<-");
            System.out.println("Elija una de las siguientes opciones: ");
            System.out.println("1) Suma");
            System.out.println("2) Resta");
            System.out.println("3) Multiplicacion");
            System.out.println("4) Division");
            System.out.println("5) Seno del angulo");
            System.out.println("6) Coseno del angulo");
            System.out.println("7) Tangente del angulo");
            System.out.println("8) Raiz n-esima");
            System.out.println("9) Potencia n-esima");
            System.out.println("10) Calculo de IVA");
            System.out.println("11) Salir");
            tipo= in.nextInt();
            switch(tipo){
                case 1 -> {
                    System.out.println("Digite el numero a sumar: ");
                    num1=in.nextFloat();
                    System.out.println("Digite el otro numero a sumar: ");
                    num2=in.nextFloat();
                    res=num1+num2;
                    System.out.println("El resultado de la suma es: "+ res);
                }
                case 2 -> {
                    System.out.println("Digite el numero a restar: ");
                    num1=in.nextFloat();
                    System.out.println("Digite el otro numero a restar: ");
                    num2=in.nextFloat();
                    res=num1-num2;
                    System.out.println("El resultado de la resta es: "+ res);
                }
                case 3 -> {
                    System.out.println("Digite el numero a multiplicar: ");
                    num1=in.nextFloat();
                    System.out.println("Digite el otro numero a multiplicar: ");
                    num2=in.nextFloat();
                    res=num1*num2;
                    System.out.println("El resultado de la multiplicacion es: "+ res);
                }  
                case 4 -> {
                    System.out.println("Digite el numero a dividir: ");
                    num1=in.nextFloat();
                    System.out.println("Digite el numero divisor: ");
                    num2=in.nextFloat();
                    if(num2==0){
                        System.out.println("Division por 0... Error");
                        break;
                    }
                    res=num1/num2;
                    System.out.println("El resultado de la division es: "+ res);
                }
                case 5 -> {
                    System.out.println("Digite el angulo: ");
                    ang=in.nextDouble();
                    rad=Math.toRadians(ang);
                    tot=Math.sin(rad);
                    System.out.println("El seno de "+ang+" es: "+tot);
                }
                case 6 ->{
                    System.out.println("Digite el angulo: ");
                    ang=in.nextDouble();
                    rad=Math.toRadians(ang);
                    tot=Math.cos(rad);
                    System.out.println("El coseno de "+ang+" es: "+tot);
                }
                case 7 -> {
                    System.out.println("Digite el angulo: ");
                    ang=in.nextDouble();
                    if(ang==90||ang==270){
                        System.out.println("Math error...");
                        break;
                    }
                    rad=Math.toRadians(ang);
                    tot=Math.tan(rad);
                    System.out.println("La tangente de "+ang+" es: "+tot);
                }
                case 8 ->{
                    System.out.println("Digite el numero base: ");
                    base=in.nextDouble();
                    if(base<0){
                        System.out.println("Raiz de numero negativo...Error");
                        break;
                    }
                    System.out.println("Digite la raiz aplicable");
                    pot=in.nextDouble();
                    pot=1/pot;
                    tot=Math.pow(base, pot);
                    System.out.println("La raiz "+1/pot+"-esima de "+base+" es: "+tot);
                }
                case 9 -> {
                    System.out.println("Digite el numero base: ");
                    base=in.nextDouble();
                    System.out.println("Digite la potencia:");
                    pot=in.nextDouble();
                    tot=Math.pow(base, pot);
                    System.out.println("La potencia "+pot+"-esima de "+base+" es: "+tot);
                }
                case 10 -> {
                    System.out.println("Digite el valor monetario: ");
                    num1=in.nextFloat();
                    System.out.println("Digite el porcentaje de IVA: ");
                    num2=in.nextFloat();
                    res=num1*(num2/100);
                    System.out.println("El valor del IVA es de: "+res);
                }
                case 11->{
                    acc="n";
                }
                default -> System.out.println("Opcion no disponible...");
            }
            System.out.println("Presione Enter para continuar...");
            try {
            new BufferedReader(new InputStreamReader(System.in)).readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
        }while("".equals(acc));  
    }   
}